<?php
header("Content-Type:application/json;charset=UTF-8");
//echo(json_encode($_POST));
echo(json_encode($_FILES));
?>